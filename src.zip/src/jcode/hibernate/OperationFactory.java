package jcode.hibernate;

import java.util.Iterator;
import java.util.List;
import jcode.hibernate.model.Employee;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author faka
 */
public class OperationFactory {
        private Session session = null;
        public void Insert(Object a){
            try {
                session = PersonFactory.getSessionFactory().getCurrentSession();
                System.out.println("Insertando registro");
                Transaction tx = session.beginTransaction();
                session.save(a);
                tx.commit();
                System.out.println("Finalizado...");
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
        
        public void CloseSession(){
            PersonFactory.getSessionFactory().close();
        }
        
        public Query Select(String AQuery){
            Query slist = null;
            try {
                session = PersonFactory.getSessionFactory().openSession();
                System.out.println("Listando registros");
                slist = session.createQuery(AQuery);
                System.out.println("Finalizado...");
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
            return slist;
        }
        
        public List SelectAllEmployees(){
            return Select("from Employee").list();
        }
        
        public void showList(List list){
            Iterator iter = list.iterator();
            if (!iter.hasNext()) {
                System.out.println("No hay empleados para listar");
            }
            while (iter.hasNext()) {
                Employee emp = (Employee) iter.next();
                String msg = emp.getFirstname();
                System.out.println(msg);
            }
        }
}
