package jcode.hibernate;

import jcode.hibernate.controller.Authentication;
import jcode.hibernate.model.Employee;
import jcode.hibernate.model.UserEmployee;

public class JcodeHibernate {
 
    public static void main(String[] args) {
        OperationFactory a = new OperationFactory();
        //Para mostrar registros
        
        UserEmployee usr = new UserEmployee();
        usr.setUsername("f4ka");
        usr.setPassword("1234");
        Employee emp = new Employee();
        emp.setFirstname("Facundo");
        emp.setLastname("Gomez Algazan");
        emp.setCellphone("+5493816534690");
        usr.setEmployee_id(emp);
        a.Insert(usr);
        Authentication auth = Authentication.getInstance();
        auth.initSession(usr);
        if (auth.getSession() != null){
            a.Insert(auth.getSession());
        }
        a.CloseSession();
    }
}   