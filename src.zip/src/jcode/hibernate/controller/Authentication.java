package jcode.hibernate.controller;

import jcode.hibernate.model.Session;
import jcode.hibernate.model.UserEmployee;

/**
 *
 * @author faka
 */
public class Authentication {    
    private static Authentication instance = null;
    private static Session SID = null;
    protected Authentication() {
      // Exists only to defeat instantiation.
   }
   public void initSession(UserEmployee usr) {
      if(SID == null) {
         SID = new Session("Y", usr);
      }
   }
   public static Authentication getInstance(){
       if(instance == null)
        instance = new Authentication();
       return instance;
   }
   public Session getSession(){
       return SID;
   }
}


 
   
